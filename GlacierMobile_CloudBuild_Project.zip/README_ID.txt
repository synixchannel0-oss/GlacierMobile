GLACIER MOBILE - proyek pendamping Android

Ini source project, bukan APK siap instal. Aplikasi memberi panduan performa dan profil panduan; tidak memodifikasi Blood Strike, tidak menyuntikkan kode, dan tidak membuka FPS yang tidak didukung.

Build dari HP tanpa PC:
1. Buat/login akun GitHub di github.com.
2. Buat repository baru.
3. Unggah seluruh isi folder proyek ini, termasuk .github/workflows/android.yml.
4. Buka tab Actions, pilih "Build Glacier Mobile APK", lalu Run workflow.
5. Setelah workflow hijau, buka hasil run dan unduh artifact GlacierMobile-debug-apk.
6. Ekstrak artifact ZIP, lalu instal app-debug.apk.

Build memakai Android Gradle Plugin 8.6.1, Gradle 8.7, JDK 17, dan Android SDK 35.
Layar 60 Hz tidak dapat menampilkan 240 FPS.
