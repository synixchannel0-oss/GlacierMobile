package com.glaciermobile.companion;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(8, 13, 24);
    private final int panel = Color.rgb(17, 27, 45);
    private final int blue = Color.rgb(56, 169, 255);
    private TextView status;

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextColor(Color.WHITE); t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private void card(LinearLayout root, String title, String detail) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL); box.setPadding(18,16,18,16);
        box.setBackgroundColor(panel);
        TextView h = text(title,17,true); h.setTextColor(blue); box.addView(h);
        TextView d = text(detail,14,false); d.setPadding(0,8,0,0); box.addView(d);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2);
        p.setMargins(0,0,0,14); root.addView(box,p);
    }
    private void action(LinearLayout root, String label, String message) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(28,91,145)));
        root.addView(b,new LinearLayout.LayoutParams(-1,-2));
        b.setOnClickListener(v -> status.setText(message));
    }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        ScrollView scroll = new ScrollView(this); scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(20,24,20,24);
        scroll.addView(root);
        TextView logo = text("GLACIER",30,true); logo.setTextColor(blue); logo.setGravity(Gravity.CENTER); root.addView(logo);
        TextView sub = text("MOBILE • BLOOD STRIKE COMPANION",11,true); sub.setGravity(Gravity.CENTER); root.addView(sub);
        status = text("Profil: Seimbang • Mode panduan aktif",14,true); status.setPadding(0,22,0,14); root.addView(status);
        card(root,"FPS BOOST GUIDE","Tutup aplikasi latar yang tidak diperlukan, gunakan grafis yang stabil, dan jaga suhu HP. Aplikasi ini tidak mengubah mesin game.");
        card(root,"BATAS REFRESH RATE","Kamu melaporkan layar 60 Hz. Layar 60 Hz tidak dapat menampilkan 240 frame berbeda per detik. FPS juga bergantung pada dukungan game dan perangkat.");
        card(root,"FPS UNLOCK","Tidak ada unlock paksa. Mengubah file game atau melewati anti-cheat dapat menyebabkan crash atau sanksi akun.");
        card(root,"SENSITIVITY & HUD","Atur sensitivitas dan tata letak HUD dari menu resmi Blood Strike. Catat nilai awal sebelum mengubahnya.");
        TextView heading = text("PILIH PROFIL PANDUAN",16,true); heading.setPadding(0,4,0,8); root.addView(heading);
        action(root,"HEMAT DAYA","Profil: Hemat daya • turunkan grafis bila game tersendat");
        action(root,"SEIMBANG","Profil: Seimbang • mulai dari grafis rendah/menengah");
        action(root,"PERFORMA","Profil: Performa • tutup aplikasi latar dan jaga suhu perangkat");
        TextView note = text("Tombol profil hanya menampilkan panduan; tidak mengubah Blood Strike secara otomatis.",12,false);
        note.setTextColor(Color.LTGRAY); note.setPadding(0,18,0,8); root.addView(note);
        setContentView(scroll);
    }
}
